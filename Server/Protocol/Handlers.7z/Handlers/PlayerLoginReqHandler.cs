
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YSFreedom.Common.Protocol;
using YSFreedom.Common.Protocol.Messages;
using YSFreedom.Server.Game;

namespace YSFreedom.Server.Protocol.Handlers
{
    public class PlayerLoginReqHandler : IYuanShenHandler
    {
        public PlayerLoginReqHandler() { }
        public async Task HandleAsync(YuanShenPacket packet, Player player)
        {
            MsgPlayerLoginReq req = (MsgPlayerLoginReq)packet;

            // Send player props here?

            MsgPlayerDataNotify playerDataNotify = new MsgPlayerDataNotify
            {
				metaData = new PacketHead
				{
					SentMs = (ulong)DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
					ClientSequenceId = req.metaData.ClientSequenceId,
				},
				packetBody = new PlayerDataNotify
				{
					NickName = player.Account.NickName,
					RegionId = 49,
					ServerTime = (ulong)DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
				}
            };
			playerDataNotify.packetBody.PropMap.Add(new PlayerDataProperties
			{
				XP = 1234,
				Primogems = 65536,
				WorldLevel = 1,
			});
			await player.Session.SendAsync(playerDataNotify.AsBytes());

            MsgResinChangeNotify resinChangeNotify = new MsgResinChangeNotify
            {
                metaData = new PacketHead
                {
                    SentMs = (ulong)DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                    ClientSequenceId = req.metaData.ClientSequenceId,
                },
                packetBody = new ResinChangeNotify
                {
                    CurValue = 160,
                }
            };
            await player.Session.SendAsync(resinChangeNotify.AsBytes());

            MsgPlayerLoginRsp rsp = new MsgPlayerLoginRsp
            {
                metaData = new PacketHead
                {
                    SentMs = (ulong)DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                    ClientSequenceId = req.metaData.ClientSequenceId,
                },
                packetBody = new PlayerLoginRsp
                {
                    IsUseAbilityHash = true,
                    GameBiz = "hk4e_global",
                    ClientDataVersion = 2762856,
                    ClientSilenceDataVersion = 2771742,
                    ClientMd5 = "{\"fileSize\": 4401, \"remoteName\": \"data_versions\", \"md5\": \"144149abbc0bd5fd5d2a8a42dbe28c7a\"}",
                    ClientVersionSuffix = "4ebb02e19b",
                    ClientSilenceVersionSuffix = "99f775138c",
                    CountryCode = player.Account.CountryCode,
                    RegisterCps = "mihoyo",
                    TargetUid = 708845657,
                },
            };

            await player.Session.SendAsync(rsp.AsBytes());
        }
    }
}

